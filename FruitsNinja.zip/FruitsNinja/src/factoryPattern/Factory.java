package factoryPattern;

public interface Factory {
	
	 public Product getProduct(String productType );
}
