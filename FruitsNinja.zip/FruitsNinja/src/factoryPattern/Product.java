package factoryPattern;

public interface Product {

}
