/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.io.File;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author ABD-ELRAHMAN
 */
public class Homescreen {
    Scene scene;
    Stage stage;
    Gameplayscreen gameplayscreen;
    ImageView imageView1;
    ImageView imageView2;
    Pane root = new Pane();




    
    public void preparescene(){
        	scene = new Scene(root, 1000, 600);
                
  	       	File file1 = new File("./src/icons/background2.png");
	        Image image1 = new Image(file1.toURI().toString());
                imageView1 = new ImageView();
                imageView1.setImage(image1);
                imageView1.fitWidthProperty().bind(scene.widthProperty()); 
                imageView1.fitHeightProperty().bind(scene.heightProperty());
                root.getChildren().add((Node)imageView1);
            
                
            	File file2 = new File("./src/icons/gobutton.png");
	        Image image2 = new Image(file2.toURI().toString());
                imageView2 = new ImageView();
                imageView2.setImage(image2);
                imageView2.setFitWidth(150);
                imageView2.setFitHeight(150);
                imageView2.setLayoutX(430);
                imageView2.setLayoutY(350);
                root.getChildren().add((Node)imageView2);
                //MOUSE ACTION HANDLER               
                imageView2.setOnMouseClicked(new EventHandler<MouseEvent>() {                      	                                       
                        @Override                        
                        public void handle(MouseEvent event) {
                            gameplayscreen.prepareScene();
                            stage.setScene(gameplayscreen.getsScene());
                        }
                    });
            
    }

    Scene getsScene() {
        return  this.scene;
    }

    public void setGameplayscreen(Gameplayscreen gameplayscreen) {
        this.gameplayscreen = gameplayscreen;
    }

    public Homescreen(Stage stage) {
        this.stage = stage;
    }

}
