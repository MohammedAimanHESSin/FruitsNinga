package CommandPattern;

public class File implements Receiver {

	public File() {
		// TODO Auto-generated constructor stub
	}
	
	public void save() 
	{
		//IMP OF SAVING 
		System.out.println("SAVING FILE Here NOW !!");
	}
	public void load() 
	{
		//IMP OF SAVING 
		System.out.println("LOADING FILE Here NOW !!");
	}
	 
}
