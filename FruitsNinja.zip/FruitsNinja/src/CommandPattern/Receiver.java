package CommandPattern;

public interface Receiver {

}
