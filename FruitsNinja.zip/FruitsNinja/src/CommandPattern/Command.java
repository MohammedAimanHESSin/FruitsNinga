package CommandPattern;

public interface Command {
	
public void excute();

}
